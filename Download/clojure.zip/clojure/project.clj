(defproject cloud/finance/rest "v1"
  :description "Client library of cloud/finance/rest"
  :dependencies [[org.clojure/clojure "1.7.0"]
                 [clj-http "2.0.0"]
                 [cheshire "5.5.0"]])
