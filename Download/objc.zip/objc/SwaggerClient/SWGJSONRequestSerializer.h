#import <Foundation/Foundation.h>
#import <AFNetworking/AFURLRequestSerialization.h>

@interface SWGJSONRequestSerializer : AFJSONRequestSerializer
@end
