#import <Foundation/Foundation.h>
#import <JSONModel/JSONModel.h>

@interface SWGObject : JSONModel
@end
