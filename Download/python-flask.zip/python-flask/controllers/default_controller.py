
def price_get_by_ticker(apikey, ticker) -> str:
    return 'do some magic!'

def price_get(apikey, ticker, date) -> str:
    return 'do some magic!'
