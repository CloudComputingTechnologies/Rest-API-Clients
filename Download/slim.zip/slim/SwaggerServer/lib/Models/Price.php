<?php
/*
 * Price
 */
namespace SwaggerServer\lib\Models;

/*
 * Price
 */
class Price {
    /* @var DateTime $date  */
    private $date;
    /* @var string $ticker  */
    private $ticker;
    /* @var double $value  */
    private $value;
    
}
