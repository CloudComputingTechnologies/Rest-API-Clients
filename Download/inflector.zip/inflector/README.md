# Swagger Inflector

Run with

```
mvn package jetty:run
``

