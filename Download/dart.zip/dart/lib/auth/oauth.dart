part of api;

class OAuth implements Authentication {

  @override
  void applyToParams(Map<String, String> queryParams, Map<String, String> headerParams) {
    // TODO: support oauth
  }
}