part of api;

class ApiException implements Exception {
  int code = 0;
  String message = null;

  ApiException(this.code, this.message);

}